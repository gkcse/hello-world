package com.test.details;

public class ApnaException extends Exception {

	public ApnaException(String string) {
		// TODO Auto-generated constructor stub
		
		System.out.println(string);
	}

}
