/**
 * 
 */
package com.test.details;

/**
 * @author GAURAV
 *
 */
public class CustomerDetails {
	
	private String customerName;
	private int customerAge;
	private String customerPincode;
	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}
	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	/**
	 * @return the customerAge
	 */
	public int getCustomerAge() {
		return customerAge;
	}
	/**
	 * @param customerAge the customerAge to set
	 * @throws ApnaException 
	 */
	public void setCustomerAge(int customerAge) throws ApnaException {
		
		if ( 18<=customerAge ){
		this.customerAge = customerAge;
		}else
		{
			
			throw new ApnaException(this.getCustomerName() +" 's Age is below 18 ");
		}
		
		
	}
	/**
	 * @return the customerPincode
	 */
	public String getCustomerPincode() {
		return customerPincode;
	}
	/**
	 * @param customerPincode the customerPincode to set
	 */
	public void setCustomerPincode(String customerPincode) {
		this.customerPincode = customerPincode;
	}

}
