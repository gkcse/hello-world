/**
 * 
 */
package com.test.customer;

import java.util.Scanner;

import com.test.details.ApnaException;
import com.test.details.CustomerDatabase;
import com.test.details.CustomerDetails;

/**
 * @author GAURAV
 *
 */
public class Customer {

	/**
	 * @param args
	 * @throws ApnaException 
	 */
	
	
	
	public static void main(String[] args) throws ApnaException {
		// TODO Auto-generated method stub
		CustomerDetails cref = new CustomerDetails();
		
		Scanner sc=new Scanner(System.in); 
		
		System.out.println("Welcome to CMS");
		
		//Take input
		System.out.println("Enter Name :");
		cref.setCustomerName(sc.next());
		
		System.out.println( "Whats your age " + cref.getCustomerName() + " ?");
		cref.setCustomerAge(sc.nextInt());
		
		System.out.println(cref.getCustomerName()  + " please enter your area pincode.");
		cref.setCustomerPincode(sc.next());
		
		System.out.println( "Thanks for the information. ");
		
		//add Entry to database now
		CustomerDatabase.databaseEntry(cref);
		
		
	   System.out.println("To view all records press 1");
	   
	   int a = sc.nextInt();
	   if(a==1)
	   {
		   CustomerDatabase.dataViewer();
	   }
	}

}
