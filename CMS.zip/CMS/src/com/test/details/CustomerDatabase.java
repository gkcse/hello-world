/**
 * 
 */
package com.test.details;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * @author GAURAV
 *
 */
public abstract class CustomerDatabase {

	// JDBC driver name and database URL
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://localhost/test";

	// Database credentials
	static final String USER = "root";
	static final String PASS = "12345";

	static public void databaseEntry (CustomerDetails ref) {
	   Connection conn = null;
	   Statement stmt = null;
	   try{
	      //STEP 2: Register JDBC driver
	      Class.forName("com.mysql.jdbc.Driver");

	      //STEP 3: Open a connection
	      System.out.println("Connecting to database...");
	      conn = DriverManager.getConnection(DB_URL,USER,PASS);

	      System.out.println("Inserting records into the table...");
	      stmt = conn.createStatement();
	      //STEP 4: Execute a query
	     // String SQL = "CREATE TABLE Customer ( Name varchar(255), Age int , Pincode varchar(255))";
	      
	      String sql = "INSERT INTO customer " +
                  "VALUES ('" + ref.getCustomerName()+ "'," +ref.getCustomerAge() +",'" + ref.getCustomerPincode() + "')";          
	   
	      stmt.executeUpdate(sql);
	      
	      System.out.println(ref.getCustomerName() + "created");  
	      conn.close();
	      stmt.close();
	   }catch(SQLException se){
	      //Handle errors for JDBC
	      se.printStackTrace();
	   }catch(Exception e){
	      //Handle errors for Class.forName
	      e.printStackTrace();
	   }finally{
	      //finally block used to close resources
	      
	      try{
	         if(conn!=null)
	            conn.close();
	      }catch(SQLException se){
	         se.printStackTrace();
	      }//end finally try
	   }//end try
	   System.out.println("Goodbye!");
	}// end main
}
