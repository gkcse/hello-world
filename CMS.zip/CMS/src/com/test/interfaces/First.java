/**
 * 
 */
package com.test.interfaces;

/**
 * @author GAURAV
 *
 */
public interface First {

}
